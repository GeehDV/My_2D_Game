/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package objects;

import java.io.IOException;
import javax.imageio.ImageIO;

/**
 *
 * @author Geovanna
 */
public class OBJ_JavaCup extends SuperObject {
    
    
    public OBJ_JavaCup (){
        
        name = "JavaCup";
        try{
            image = ImageIO.read(getClass().getResourceAsStream("/image_objects/javacup.png"));
                       
        }catch(IOException e){
            e.printStackTrace();
        }
        
        collision = true;
    }
    
}
